PyGraph:
This framework is a high preformance framework mostly built on cython, numpy, and cython. It has a documentation (https://docs.google.com/document/d/e/2PACX-1vQOwu2Af64UuxCGlzJDqdMTuFUCGLhgEevXPQREf4ztSdDBWjDFSGKGgnLvW_XRHIjl9YneM9xuUYKz/pub) which is nessesary to master this framework
